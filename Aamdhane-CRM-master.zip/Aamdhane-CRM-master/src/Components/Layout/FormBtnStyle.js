// eslint-disable-next-line react/jsx-filename-extension
export const innerTableActionBtnDesign = {
  fontSize: 20,
  color: '#1890ff',
  padding: '0 10px',
};
